<?Php
error_reporting(E_ALL); 
ini_set("display_errors", 1); 


include ("lib/customer.defines.php");
include ("lib/customer.module.access.php");
include('sms.class.php');

$username = mysql_real_escape_string($_GET['username']);
$password = mysql_real_escape_string($_GET['password']);
$from = urlencode($_GET['from']);
$to = urlencode($_GET['to']);
$text = urlencode($_GET['text']);

$QUERY = "SELECT  * FROM cc_card WHERE useralias = '$username' AND `uipass` = '$password'";
$DBHandle_max  = DbConnect();
$rs = $DBHandle_max -> Execute($QUERY);
$fetch = $rs->fetchRow();


$ips = array( $fetch['ip1'],$fetch['ip2'],$fetch['ip3']);
$flag = false;
for($i=0; $i<count($ips); $i++)
{
	if($_SERVER['REMOTE_ADDR'] == $ips[$i])
	{
		$flag = true;
	}
}

if(!$flag)
{
	print 'HOST NOT AVAILBLE';
	exit;
}
if(array_key_exists('username', $fetch))
{
	$to = trim($to);
		$smsRequest = 'https://www.voicetrading.com/myaccount/sendsms.php?username=israelnumber&password=piterpen&from='.$from.'&to=+'.$to.'&text='.$text;
		
		
		$SMS = new SMS ($from,"+" . $to, $text,$fetch['username'],false,8);
		$SMS->refuseHeader();
			print $SMS->sendME();
		
}
?>
