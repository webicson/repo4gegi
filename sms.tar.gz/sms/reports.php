<?php
/**
 * Written By vlad-ga
 * Date 12.01.2020
 * @Technologies LTD
 */

ini_set('memory_limit', '256M');
error_reporting(E_ALL); 
ini_set("display_errors", 1); 

include ("lib/customer.defines.php");

include ("lib/customer.module.access.php");

include ("lib/customer.smarty.php");
include('sms.class.php');

$smarty->display('main.tpl');

$page = isset($_GET['p']) ? intval($_GET['p']) : 1;
$perpage = isset($_GET['perpage']) ? intval($_GET['perpage']) : 25;

if($page == 0)
    $page = 1;
if($perpage == 0)
    $perpage = 25;

$sent = (int) @$_GET['sent'];
$destiny = @$_GET['destiny']; 

$selected = 'selected="selected"';
$perpage1 = ($perpage == 25) ? $selected : null;
$perpage2 = ($perpage == 50) ? $selected : null;
$perpage3 = ($perpage == 75) ? $selected : null;
$perpage4 = ($perpage == 100) ? $selected : null;

$sent0  = ($sent == 0) ? $selected : null;
$sent1 = ($sent == 1) ? $selected : null;
$sent2 = ($sent == 3) ? $selected : null;
$sent3 = ($sent == 2) ? $selected : null; 


print <<<EOF
<script>
function anyCheck(f) {
var t=0;
var c=f['resend[]'];
for(var i=0;i<c.length;i++){
c[i].checked?t++:null;
}
    document.getElementById('smsnum').innerHTML = t;
   jQuery.facebox({ div: '#sub' });
   document.getElementById('background').style.display="block";
   
}
</script>

<div id="background" style="z-index:100; width: 100%; height: 100%; margin: 0em;
            left: 0em; top: 0em; 
            position: fixed;background:#000; filter:alpha(opacity=30);
opacity: 0.3;
-moz-opacity:0.3; display:none;
"></div>
<div id="sub" style="z-index:999; display:none;">
<h1>SMS(s) Are Being Sent</h1>
<img src="templates/default/images/ajax-loader.gif" alt="" /><br />Sending in process...<br /><br />
<div id="smsnum" style="display:inline; font-weight:bold;"></div> SMS(s) are being sent.
<br /><br />
please be patient. </div>


<h1>SMS reports</h1>
<hr />
<form action="?p=$page" method="get"> 
<TABLE border="0" cellPadding="2" cellSpacing="2" width="100%"> 
	<TR class="form_head"> 
		<td class="tableBody" style="padding: 2px;" align="center" width="3%" > 	
		Show only: 
			<select name="sent">

				<option value="0" $sent1>all</option>
				<option value="1" $sent1>sent</option>
				<option value="3" $sent2>failed</option>
				<option value="2" $sent3>delayed</option>
			</select>
		</td>
		 <td class="tableBody" style="padding: 2px;" align="center" width="3%" > 
		Show:
			<select name="perpage">
				<option $perpage1>25</option>	
				<option $perpage2>50</option>
				<option $perpage3>75</option>
				<option $perpage4>100</option>
			</select>
			Reports
		</td>
		 <td class="tableBody" style="padding: 2px;" align="center" width="3%" > 
			<input type="hidden" name="p" value="{$page}" />
			Search number: <input type="text" name="destiny" value="$destiny" style="width:140px"/>  <input type="submit" value="Go!" />

		</td>
	</tr>
</table>
</form>



EOF;


$DB = DbConnect();

$WHERE = "WHERE `a2billinguser` = '{$_SESSION['pr_login']}'";

if($sent != 0) {

	$sent = ($sent == 3)?0:$sent;

	 $WHERE = $WHERE . " sent = '$sent' "; 
}

if($sent == 2) $WHERE = null;
if(!empty($destiny)) $WHERE = ($WHERE == null) ? "destiny = '$destiny' ":  $WHERE . " AND destiny = '$destiny'"; 

if($sent == 2)
{
	$cmd = $DB->Execute("SELECT COUNT(*) FROM `cc_sms_delayed` $WHERE");
}
else
{
	$cmd = $DB->Execute("SELECT COUNT(*) FROM `cc_sms` $WHERE ");
}

$nump = @$cmd -> fetchRow();
$nump = $nump[0];

$nump = $nump / $perpage;
if(intval($nump) != $nump)         
    $nump = intval($nump) + 1;       

$limit = ($page - 1) * $perpage;


if($sent == 2)
{
	$query = "SELECT * FROM `cc_sms_delayed` $WHERE ORDER BY `date_created` DESC LIMIT $limit,$perpage";
}
else
{
	$query = "SELECT * FROM `cc_sms` $WHERE ORDER BY `date_created` DESC LIMIT $limit,$perpage";
}
$rs = $DB->Execute($query);
@$fetch = $rs->FetchNextObj();
print <<<EOF
<form action="sms.php?multiple=t" method="post" name="resend" onsubmit="return anyCheck(this)">
<TABLE border="0" cellPadding="2" cellSpacing="2" width="100%"> 
    <TR class="form_head"> 
        <td class="tableBody" style="padding: 2px;" align="center" width="1%" >      &nbsp;</td>
		<td class="tableBody" style="padding: 2px;" align="center" width="3%" >      Destination</td>
		<td class="tableBody" style="padding: 2px;" align="center" width="3%" >      Date</td>
		<td class="tableBody" style="padding: 2px;" align="center" width="3%" >      Characters</td>
		<td class="tableBody" style="padding: 2px;" align="center" width="3%" >      Status</td>
	</tr>
EOF;
$j=0;
while($fetch)
{

        $whynot = null;
    if($fetch->whynot == 2 || $fetch->whynot == 3)
    {
    	$whynot = 'Connection problem Or BAD DESTINATION.';
    	$disabled=null;
    }
    elseif($fetch->whynot == 1)
    {
    	$whynot = 'Not enough balance to send the sms.';
    	$disabled=null;
    }
    elseif($fetch->whynot == 4)
    {
    	$whynot = 'Country prefix wasn\'t found';
    	$disabled=null;
    }
if($fetch->sent == 1) 
{
	$status = 'sent';
    $disabled = 'disabled="disabled"';
	
}
else
{
	$status = '<strong>FAILED</strong> - <a href="sms.php?resend='.$fetch->smsID.'">Resend</a> / <a href="sms.php?edit='.$fetch->smsID.'">Edit</a><br />' . $whynot;
}

if($sent == 2)
{
	if($fetch->minute<10) 
	{
		$fetch->minute = "0{$fetch->minute}";
	}
	$status = '<STRONG>Delayed to: </strong>' . "{$fetch->month}/{$fetch->day}/{$fetch->year} {$fetch->hour}:{$fetch->minute}"; 
}


		if(date("i",$fetch->date_created) < 10) 
		{
			$date = date("d/m/y - H:i",$fetch->date_created);
		}
		else
		{
			$date = date("d/m/y - H:i",$fetch->date_created);
		}

	       $content = substr($fetch->content,0,20);
		$countCont = strlen($fetch->content);
	$bg = ($j%2==0) ? "#FCFBFB" : "#F2F2EE";
	
	
                    
print <<<EOF
	<TR bgcolor="$bg"  onmouseover="bgColor='#FFDEA6'" onMouseOut="bgColor='$bg'">
	     <TD vaglin="middle" align="center" class="tableBody">
	       <input type="checkbox" value="{$fetch->smsID}" name="resend[]" $disabled />
	     </TD>
		 <TD vAlign="top" align="center" class="tableBody">
		 {$fetch->destiny}
		</td>
		 <TD vAlign="top" align="center" class="tableBody">
		 {$date}
		</td>
		 <TD vAlign="top" align="center" class="tableBody">
		 $content 
		</td>
		 <TD vAlign="top" align="center" class="tableBody">
		 $status
		</td>
	</tr>
EOF;

	$fetch = $rs->FetchNextObj();
$j++;	
}

print <<<EOF
</table>
<input type="submit" value="Resend selected" style="background:#000; color:#fff;" />
</form>
<hr />
<strong>Pages:</strong>  
EOF;

for($i=1;$i<=$nump;$i++)
{
	if($i==$page)
	{
		print $i;
	}
	else
	{
		$sent = (int) $_GET['sent'];
		$destiny = $_GET['destiny'];
		$perpage = (int) $_GET['perpage'];
		print '<a href="?sent='.$sent.'&perpage='.$perpage.'&p='.$i.'&destiny='.$destiny.'">'.$i.'</a>';
	}
}

print <<<EOF
<hr />

	<!--<a href="downloadlog.php" style="font-size:10px">Download TXT Log file. </a>-->

EOF;
//$fetch = $rs->FetchNextObj();
//print_r($fetch);
//print_r(get_class_methods('ADORecordSet_mysql'));
?>
