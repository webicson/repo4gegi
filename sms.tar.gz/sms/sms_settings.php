<?php

include ("./lib/customer.defines.php");
include ("./lib/customer.module.access.php");
include ("./lib/customer.smarty.php");
if(!isset($_SESSION["pr_login"])) exit;
error_reporting(E_ALL);
ini_set("display_errors", 1);

$smarty->display('main.tpl');
$DB = DBConnect();
$msg = '';
$username = $_SESSION['pr_login'];
if(isset($_GET['update']))
{
    $ip1 = mysql_real_escape_string($_POST['ip1']);
    $ip2 = mysql_real_escape_string($_POST['ip2']);
    $ip3 = mysql_real_escape_string($_POST['ip3']);
    $DB->Execute("UPDATE `cc_card` SET `ip1` = '$ip1' , `ip2` = '$ip2' , `ip3` = '$ip3' WHERE `username`='$username'");
    $msg = "IP list updated successfully";
}


$details = $DB->Execute("SELECT * FROM `cc_card` WHERE `username` = '$username'");
$data = $details->fetchNextObj();

print <<<HTML
<!-- header -->
<!--<span style="font-weight:bold; color: #8F3E3E;">$msg</span>-->
<div class="toggle_show2hide"> 
    <div class="tohide" style="display:visible;"> 
    <div class="msg_info">SMSs will be accepted to above link ONLY from the specified IPs <br /><br />
    Enter mobile phone number(s)<br />
in the international format<br />
(for instance, a UK mobile: +0044 77 XXX XXXX).<a href="#" target="_self" class="hide_help" style="float:right;"><img class="toggle_show2hide" src="../Public/templates/default/images/kicons/toggle_hide2show_on.png" onmouseover="this.style.cursor='hand';" HEIGHT="16"> </a> 
    </div></div></div> 

<form action="sms_settings.php?section=25&amp;update=true" name="ratesForm"  method="post">
<h2>Edit settings</h2>

    <div style="font-size:12px;">

</div>
<table cellspacing="2" class="addform_table1"> 
          <INPUT type="hidden" name="form_action" value="add"> 
          <INPUT type="hidden" name="wh" value=""> 
             <INPUT type="hidden" name="atmenu" value="card"> 
         <TBODY> 
        <TR>
            <TD width="%25" valign="top" bgcolor="#FEFEEE" colspan="2" class="tableBodyRight" >
                <i>http://212.150.158.100/a2billing/customer/sendsms.php?username={$_SESSION['pr_login']}&password={$_SESSION['pr_password']}&from=[your number]&to=[destination number]&text=[message]</i>
            </TD>
        </TR>
        <TR> 
            <TD width="%25" valign="middle" class="form_head">  &nbsp;  IP 1:      </TD>  
            <TD width="%75" valign="top" class="tableBodyRight" background="../Public/templates/default/images/background_cells.gif" class="text"> 
                 <INPUT class="form_input_text" name="ip1"  size=30 value='{$data->ip1}'  > 
           </TD> 
        </TR> 

        <TR> 
            <TD width="%25" valign="middle" class="form_head">  &nbsp;  IP 2:         </TD>  
            <TD width="%75" valign="top" class="tableBodyRight" background="../Public/templates/default/images/background_cells.gif" class="text"> 
                 <INPUT class="form_input_text" name="ip2"  size=30 value='{$data->ip2}'   maxlength=40 value=""> 
           </TD> 
        </TR> 
    
        <TR> 
            <TD width="%25" valign="middle" class="form_head">  &nbsp;  IP 3:         </TD>  
            <TD width="%75" valign="top" class="tableBodyRight" background="../Public/templates/default/images/background_cells.gif" class="text"> 
                 <INPUT class="form_input_text" name="ip3"  size=30 value='{$data->ip3}'   maxlength=40 value=""> 
           </TD> 
        </TR>   
    </table>
    
    
              <TABLE cellspacing="0" class="editform_table8" style="font-size:12px;"> 
        <tr> 
            <td width="" class="text_azul"><span>Once you have completed the form above, click on Confirm Data</span></td> 
                        <td width="" align="right" valign="top" class="text"> 
                <a href="#" onClick="javascript:document.ratesForm.submit();" class="cssbutton_big"><IMG style="vertical-align:middle;" src="../Public/templates/default/images/icon_arrow_orange.gif"> 
                CONFIRM DATA </a> 
                
            </td> 
        </tr> 
      </TABLE> 
HTML;
if(isset($_GET['update']))
{
	    print "<script>alert('$msg')</script>";
}
?>