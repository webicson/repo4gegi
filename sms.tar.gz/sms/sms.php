<?php
include ("lib/customer.defines.php");
include ("lib/customer.module.access.php");
include ("lib/customer.smarty.php");
include('sms.class.php');



if (!has_rights(ACX_ACCESS)) {
        Header("HTTP/1.0 401 Unauthorized");
        Header("Location: PP_error.php?c=accessdenied");
        die();
}

ini_set('memory_limit', '512M');
error_reporting(E_ALL); 
ini_set("display_errors", 1); 

$DB = DbConnect();
$rs = $DB->Execute("SELECT `chars` FROM `cc_sms_settings`");
$fetch = $rs->fetchObj();
define('CHARS',$fetch->chars);
//define('CHARS',0);

		//$DBHandle_max  = DbConnect();
		//$DBHandle_max -> Execute("DELETE FROM `cc_sms`");

//print date("H:i");
$smarty->display('main.tpl');
//vl
//define('CHARS',70);
$multichars = CHARS - 3;
        function str_split_unicode($content, $l = CHARS) 
        {
        $l = $l - 3; 
        if ($l > 0) {
         $ret = array();
         $len = mb_strlen($content, "UTF-8");
         //var_dump($len);exit;
         if ($len > 70) 
         {
         //var_dump($len);exit;
         $l = $l*6;
         for ($i = 0; $i < $len; $i += $l) {
             $ret[] = mb_substr($content, $i, $l, "UTF-8");
                                           }
       //   var_dump($ret);exit;
         return $ret;
         }            
         
         else 
         {
         $ret[] = mb_substr($content, 0, $len, "UTF-8");
         return $ret;
         
         }
        // return preg_split("//u", $content, -1, PREG_SPLIT_NO_EMPTY);
         }                   
        }     

function _uniord($c) {
    if (ord($c{0}) >=0 && ord($c{0}) <= 127)
        return ord($c{0});
    if (ord($c{0}) >= 192 && ord($c{0}) <= 223)
        return (ord($c{0})-192)*64 + (ord($c{1})-128);
    if (ord($c{0}) >= 224 && ord($c{0}) <= 239)
        return (ord($c{0})-224)*4096 + (ord($c{1})-128)*64 + (ord($c{2})-128);
    if (ord($c{0}) >= 240 && ord($c{0}) <= 247)
        return (ord($c{0})-240)*262144 + (ord($c{1})-128)*4096 + (ord($c{2})-128)*64 + (ord($c{3})-128);
    if (ord($c{0}) >= 248 && ord($c{0}) <= 251)
        return (ord($c{0})-248)*16777216 + (ord($c{1})-128)*262144 + (ord($c{2})-128)*4096 + (ord($c{3})-128)*64 + (ord($c{4})-128);
    if (ord($c{0}) >= 252 && ord($c{0}) <= 253)
        return (ord($c{0})-252)*1073741824 + (ord($c{1})-128)*16777216 + (ord($c{2})-128)*262144 + (ord($c{3})-128)*4096 + (ord($c{4})-128)*64 + (ord($c{5})-128);
    if (ord($c{0}) >= 254 && ord($c{0}) <= 255)    //  error
        return FALSE;
    return 0;
}   //  function _uniord()




//vl


if(isset($_GET['multiple']))
{
	$post = $_POST['resend'];
	foreach($post as $id)
	{
	    $DBHandle_max  = DbConnect();
	    $id = intval($id);
	    $rs= $DBHandle_max->Execute("SELECT * FROM `cc_sms` WHERE `smsID` = '$id'");
	    $fetch = $rs->fetchNextObj();
	
	    $SMS = new SMS ($fetch->callerid, $fetch->destiny,$fetch->content,$_SESSION['pr_login']);
	        
	    //print "\$SMS = new SMS ($fetch->callerid, $fetch->destiny,$fetch->content,{$_SESSION['pr_login']});";
	        $SMS->sendME();
	}
	
	exit;
}
if(isset($_GET['resend']) && intval($_GET['resend']))
{
	$DBHandle_max  = DbConnect();
	$id = intval($_GET['resend']);
	$rs= $DBHandle_max->Execute("SELECT * FROM `cc_sms` WHERE `smsID` = '$id'");
	$fetch = $rs->fetchNextObj();

	$SMS = new SMS ($fetch->callerID, $fetch->destiny,$fetch->content,$_SESSION['pr_login'],true);
		
		$SMS->sendME();
exit;
}


if(isset($_POST['form_sent']))
{
    $callerID = mysql_escape_string($_POST['callerid']);
    $destiny = trim($_POST['destiny']);
    $content = $_POST['content'];
   // var_dump(_uniord($content));exit; 
//    $illegal = preg_replace("/[A-Za-z0-9 ]*[A-Za-z0-9][A-Za-z0-9 ]*/",'',$content);
     $illegal=0;

    if(strlen($illegal) > 0)
    {


        $msg = 'Please enter a valid content!.';
    }
    
    $destiny = explode(";",($destiny));
    
    if(count($destiny) == 1) 
    {
        $destiny = $destiny[0];
    }

    if(intval($_POST['sendnow']) == 0) 
    {
 //   	$split = str_split($content,CHARS);
   

        $split = str_split_unicode($content, $l = CHARS);
 

               
    
                $price_k=1;

    		foreach($split as $text)
    		{
                $len1 = mb_strlen($text, "UTF-8");
                if ($len1 > 70)
                {
                $price_k = (int)($len1 / 67);
         //$l = $l*3;
         //var_dump($len);exit;
                $rem = $len1 % 67;
                if ($rem > 0)
                $price_k = $price_k + 1;
                }
                else
                $price_k=1;
           
                       $SMS = new SMS ($callerID, $destiny, $text,$_SESSION['pr_login'],false,8,0,$price_k);
		        print '1) ('.$destiny[0].')'.$SMS->getCountryCode($destiny[0],-1,$destiny[0]);
//                       var_dump($test);
     		       // print '<br />2) ('.trim($destiny[1]).')'.$SMS->getCountryCode(trim($destiny[1]),-1,trim($destiny[1]));
		        $SMS->sendME();
    		}
//    exit;	


    }
    else
    {   

        
        $day = $_POST['day'] ;
        $month = $_POST['month'];
        $year = $_POST['year'];
        $hour = $_POST['hour'];
        $minute = $_POST['minute'];

        $date_created = time();
        $a2billinguser =  $_SESSION['pr_login'];
        $DBHandle_max  = DbConnect();
        $QUERY = "INSERT INTO `cc_sms_delayed` (date_created,callerid,destiny,content,a2billinguser,day,month,year,hour,minute) VALUES ('$date_created','$callerID','$destiny','$content','$a2billinguser','$day','$month','$year','$hour','$minute')"; // username = '".$_SESSION["pr_login"]."' AND uipass = '".$_SESSION["pr_password"]."'";
        $DBHandle_max -> Execute($QUERY);
            header("location: reports.php?sent=2&perpage=25&p=1&destiny=");
    }       
        
}


if(isset($_GET['edit']))
{
	$DB = DbConnect();
	$user =  $_SESSION['pr_login'];
	$id = intval($_GET['edit']);
	//print $user . $id; exit;
	$rs = $DB->Execute("SELECT * FROM `cc_sms` WHERE `smsID` = '$id' AND `a2billinguser` = '$user'");
	$fetch = $rs->fetchNextObj();
	$callerid = $fetch->callerid;
	$content = $fetch->content;
	$destiny = $fetch->destiny;
}
else
{
	$callerid = '';
    $content = '';
    $destiny = '';
}
?>

<script>
//window.numMsgs = 1;
function hmc(what)
{
    var numMsgs;
	//window.numMsgs = what.value.length/160;
	
	/*if(what.value.length >= 160*window.numMsgs)
	{
		window.numMsgs++;
		document.getElementById('numMsgs').innerHTML = window.numMsgs;
	}
	else
	{
	    window.numMsgs = 160*window.numMsgs/what.value.length;
	}*/

        if(Math.floor((what.value.length-1)/<?php print CHARS; ?>) == 0) 
        { 
	numMsgs = Math.floor((what.value.length-1)/<?php print CHARS; ?>) + 1;

        document.getElementById('numMsgs').innerHTML = numMsgs;
        document.getElementById("counter").innerHTML = "<b>" + ((<?php print CHARS; ?>*numMsgs)-parseInt(what.value.length)) + "</b>";

        }
        else
        {
        numMsgs = Math.floor((what.value.length-1)/<?php print $multichars; ?>) + 1;
        document.getElementById('numMsgs').innerHTML = numMsgs;
        document.getElementById("counter").innerHTML = "<b>" + ((<?php print $multichars; ?>*numMsgs)-parseInt(what.value.length)) + "</b>";

        }
    
	//document.getElementById("counter").innerHTML = numMsgs + "=>" + what.value.length/160;





}

function IsNumeric(sText)

{
   var ValidChars = "0123456789.";
   var IsNumber=true;
   var Char;

 
   for (i = 0; i < sText.length && IsNumber == true; i++) 
      { 
      Char = sText.charAt(i); 
      if (ValidChars.indexOf(Char) == -1) 
         {
         IsNumber = false;
         }
      }
   return IsNumber;
   
   }
function trim(str, chars) {
    return ltrim(rtrim(str, chars), chars);
}
 
function ltrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}
 
function rtrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}

function checkContent(form)
{
	var flag = true;
  //  if(document.getElementById('content').value.replace(/[A-Za-z0-9 ]*[A-Za-z0-9][A-Za-z0-9 ]*/,'').length > 0)
  //  {
  //      flag = false;
   //     document.getElementById('counter').innerHTML =  "<strong style=\"color: #AF0A0A;\">Enter valid text only!</strong> <br /> <b>" + ((160)-parseInt(document.getElementById('content').value.length)) + "</b>";
  //  }

    var errs = '';
    var arr = document.getElementById('phones').value.split(';');
    if(trim(document.getElementById('phones').value) == '')
    {
        errs += "<strong style=\"color: #AF0A0A;\">No numbers where entered.</strong><br /> ";
        flag = false;
    }
    else
    {
        var j=0;
	    for(var i =0; i<arr.length; i++)
	    {
	    	
	       // alert(arr[i].substring(0,3));
		    if(trim(arr[i]) != '')
		    {
		        if(arr[i].substring(0,3) != '+00' || IsNumeric(arr[i].replace('+','')) == false)
		        {
		        	flag = false;
		        
		            errs += "<strong style=\"color: #AF0A0A;\">"+arr[i]+"</strong><br /> ";
		        }
		        j++;
		    }
	        //return false;
	    }
    }
  
   if(flag == false)
   {
	  errs = "<strong style=\"color: #AF0A0A;\">Error! check for non-legal characters including spaces in the following numbers: </strong><br />" + errs;
   }
   document.getElementById('destination_errs').innerHTML = errs;
   if(flag == false)
   {
	   return false;
   }

   
    
   document.getElementById('numsms').innerHTML = "<strong>"+(parseInt(document.getElementById('numMsgs').innerHTML))+"</strong>";
   document.getElementById('numdest').innerHTML = "<strong>"+(j)+"</strong>";
   document.getElementById('background').style.display="block";
   jQuery.facebox({ div: '#sub' });

   return true;
}

</script>
<div id="background" style="z-index:100; width: 100%; height: 100%; margin: 0em;
            left: 0em; top: 0em; 
            position: fixed;background:#000; filter:alpha(opacity=30);
opacity: 0.3;
-moz-opacity:0.3; display:none;
"></div>
<div id="sub" style="z-index:999; display:none;">
<h1>SMSs Are Being Sent</h1>
<img src="templates/default/images/ajax-loader.gif" alt="" /><br />Sending in process...<br /><br />
You sent <div id="numsms" style="display:inline;"></div> SMSs to <div id="numdest" style="display:inline"></div> destinations, this could take a while, dont close the window. <br />
when the operation will be done, you will be redirected to the reports page. <br /><br />
please be patient. </div>
<h1>Send SMS</h1>
    <div class="toggle_show2hide"> 
    <div class="tohide" style="display:visible;"> 
    <div class="msg_info">we have limited control over receiving end party.<br />
      In some cases landlines networks might accept SMS sent. <br />
       Your account will be charge for SMSs sent, regardless of destination.
    <a href="#" target="_self" class="hide_help" style="float:right;"><img class="toggle_show2hide" src="./templates/default/images/toggle_hide2show_on.png" onmouseover="this.style.cursor='hand';" HEIGHT="16"> </a> 
    </div></div></div> 
<!-- <form action="" method="post">  --> 
 <form action="" method="post" onsubmit="return checkContent();">
<table>
	<tr>
		<td>Sender CallerID:<br /><span  style="coloer:#efefef; font-size:9px;font-weight:bold;">Enter only numeric values</span></td>
		<td><input type="text" value="<?php echo $callerid;?>" name="callerid" style="border:1px solid #000;"/></td>
	</tr>
	<tr>
	   <td>&nbsp;</td>
	</tr>
	<tr>
		<td style="vertical-align:top">Enter your text message here <br />(1 SMS counted as  <?php print CHARS; ?> characters,<br> otherwise counted by <?php print CHARS-3; ?> characters each) :<br /><span  style="coloer:#efefef; font-size:9px;font-weight:bold;">Please use A - Z, 0 - 9 charachters only, <br />all others will be rejected!</span></td>
		<td valign="top"><textarea id="content" onkeydown="hmc(this)" onkeyup="hmc(this)" cols="80" rows="10" name="content" style="border:1px solid #000;font-size:12px;"><?php echo $content;?></textarea><br /><div id="counter" style="display:inline; color: #45A8DF;"><b><?php print CHARS; ?></b></div> chars left. Total: <div id="numMsgs" style="display:inline; font-weight:bold; color: #45A8DF;">1</div> messages. <br /> messages longer then <span style="font-weight:bold; color:#45A8DF;"><?php echo CHARS; ?></span> chars, will be sent in seperate SMSs.</td>
	</tr>
    <tr>
       <td>&nbsp;</td>
    </tr>
	<tr>
		<td style="vertical-align:top">Enter the mobile phone number(s) <br />you want to text (separated with <strong>;</strong> between them) <br /> <span  style="coloer:#efefef; font-size:9px;font-weight:bold;">Enter mobile phone number(s)<br /> in the international format<br /> (for instance, a UK mobile: <strong>+00</strong>44 77 XXX XXXX). </span></td>		
		<td><textarea cols="80" rows="10" name="destiny" id="phones" style="border:1px solid #000; font-size:12px;"><?php echo $destiny;?></textarea><div id="destination_errs"></div></td>
	</tr>
	<tr>
		<td>
			<input type="radio" name="sendnow" value="0" checked="checked" /> Send messages now <br />	
			<input type="radio" name="sendnow" value="1" /> Send messages at the following date and time: <br />
			Date Pattern: <strong>month/day/year</strong><br />
			<select name="month">
				<script>
					for(var i=1; i<=12; i++) 
					{
						if(i == <?php print date("m"); ?>)
						{
							document.write('<option selected="selected">' + i + '</option>');
						}		
						else
						{
							document.write('<option>' + i + '</option>');
						}
					}		
				</script>
			</select>
			
			<select name="day">
				<script>
					for(var i=1; i<=31; i++) 
					{
						if(i == <?php print date("d"); ?>)
						{
							document.write('<option selected="selected">' + i + '</option>');
						}		
						else
						{
							document.write('<option>' + i + '</option>');
						}
					}		
				</script>
			</select>
			<select name="year">
				<script>
					for(var i=2013; i<=2015; i++) 
					{
						document.write('<option>' + i + '</option>');
					}		
				</script>
			</select>
			<strong>At</strong>
			<select name="hour">
				<script>
					for(var i=1; i<=24; i++) 
					{		
						var opt = '';
						if(i<10) 
						{
							opt = '0';
						}
						if(i == <?php print date("H"); ?>)
						{
							document.write('<option selected="selected">' + opt + i + '</option>');
						}		
						else
						{
							document.write('<option>' + opt + i + '</option>');
						}
		
					}		
				</script>
			</select>:
			<select name="minute">
				<script>
					for(var i=0; i<=60; i++) 
					{
						var opt = '';
						if(i<10) 
						{
							opt = '0';
						}
						if(i == <?php print date("i"); ?>)
						{
							document.write('<option selected="selected">' + opt + i + '</option>');
						}		
						else
						{
							document.write('<option>' + opt + i + '</option>');
						}
					}		
				</script>
			</select>
		</td>
	</tr>
	<tr>
		<td colspan="2" style="text-align:right"><input type="submit" name="form_sent" value="Send SMSs" style="border:1px solid #000;" /></td>
	</tr>
</table>

</form>
