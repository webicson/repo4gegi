<?Php

ini_set('include_path', "/usr/local/src/a2billing/customer");


ini_set("display_errors", 1); 
error_reporting(E_ALL); 


include ("includes/crypt.php");
include ("lib/customer.module.access.php");
include ("lib/customer.defines.php");
include('sms.class.php');
ini_set('memory_limit', '256M');




		$year = (int) date("Y");
		$day = (int) date("d");
		$month =(int)  date("m");
		$hour = (int) date("H");
		$minute =(int)  date("i");
		print "$year/$month/$day ($hour : $minute) " ;



		$DBHandle_max  = DbConnect();


		$rs = $DBHandle_max->Execute("SELECT * FROM `cc_sms_delayed` WHERE year = '$year' AND  day = '$day' AND `month`= '$month' AND `hour`= '$hour' AND `minute` = '$minute'");
		
		print "Searching .. \n"; 
		if(!$rs) exit;

		//print $fetch->destiny;
		$fetch = $rs->fetchNextObj();
		//print $fetch->destiny;
		
		
		while($fetch) 
		{


			print "Sending SMS... \n" ;
			
			$SMS = new SMS ($fetch->callerID, $fetch->destiny, $fetch->content,$fetch->a2billinguser);
				$SMS->sendME();
			//print $fetch->destiny; exit;
			$DBHandle_max -> Execute("DELETE FROM `cc_sms_delayed` WHERE `smsID` = '{$fetch->smsID}'");
			unlink($SMS);
			$fetch = $rs->fetchNextObj();
		}
?>