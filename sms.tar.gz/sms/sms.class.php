<?php
/**
 * An SMS Object class
 * Written By vlad-ga
 * Date 28.1.20
 * @ ITC IP Technologies LTD
 */

ob_start();
//session_start();
ini_set('memory_limit', '3000M');
include('excel/reader.php');

define('SRV_RATES_PATH' , '/var/www/html/a2billing/rates/');
define('WEB_RATES_PATH' , '../../rates/');

class SMS
{
	/**
	 * SMS' Sender - Caller ID
	 * @var integer 
	 */
	protected $_callerID; 
	
	/**
	 * The number or number which
	 * will get the SMS message.
	 * @var array 
	 */
	protected $_smsDestiny;
	
	/**
	 * Content of the SMS Message
	 * @var String 
	 */
	protected $_content;
	
	/**
	 * Postpone the message to a
	 * future date.
	 * @<b>TIMESTAMPS!</b>
	 * @var integer  
	 */
	protected $_delayTo = 0;
	
	/**
	 * The user who this SMS was 
	 * sent from
	 * @var integer
	 */
	protected $_a2billinguser;
	
	/**
	 * Sms' prices 
	 * @var array  
	 */
	protected $_smsPrices = array();

	protected $_smsDestinyCode = 0 ;
	
	protected $_update;
	/**
	 * File with prices of the SMS Messages 
	 * for each country and region
	 * @var string 
	 */
	protected $_smsPricesFile = "default_smsprices.xls";
	
	protected $calltype;
	
	protected $_rfh = false;
	/**
	 * Reset all params
	 * @param integer $callerID
	 * @param mixed $destiny
	 * @param string $content
	 * @param integer $delayTo
	 */
	public function __construct($callerID,$destiny,$content,$a2billinguser,$update=false,$calltype=7)
	{
		$this->_callerID = trim($callerID);
		$this->_content = $content;
		$this->_smsDestiny = $destiny;
		$this->_update = $update;
		$this->_a2billinguser=($a2billinguser);
		$this->calltype = $calltype;
		
		$this->xlsToArray();
	}
	public function refuseHeader()
	{
		$this->_rfh = true;
	}
	/**
	 * Some magic method 
	 * @param string $key
	 * @param mixed $value
	 */
	public function __set($key, $value)
	{
		$this->$key = $value;
	}
	
	/**
	 * Gets the XLS file 
	 * and turns it's data into an Array
	 */
	public function xlsToArray()
	{
		// if there isnt any file to get prices from
		if(!file_exists(SRV_RATES_PATH . $this->_a2billinguser . ".xls"))
		{
			$file = SRV_RATES_PATH . $this->_smsPricesFile ;
		}
		else
		{
			$file = SRV_RATES_PATH . $this->_a2billinguser . ".xls";
		}
		
		
			// Get content from the XLS file
			$Data = new Spreadsheet_Excel_Reader();
			$Data->read($file);
			
				// adding the cost of the prefix to an Array 
				foreach($Data->sheets[0]['cells'] as $row=>$values)
				{
					$this->setCost($values[2],$values[3],$values[1]);
				}
			
		
	}
	
	/**
	 * Return the SMS Prices
	 * as an Array
	 */
	public function getPrices()
	{
		return $this->_smsPrices;
	}
	
	/**
	 * Set a SMS cost for a certain country
	 * @param integer $areaCode
	 * @param boolean $price
	 * @param string $country
	 */
	public function setCost($areaCode,$price,$country)
	{
		$this->_smsPrices[$areaCode] = array($price,$country);
	}
	
	/**
	 * If there is more than one destiny.
	 * @see getCountryCode
	 */
	public function getCountryCodes()
	{
		$destiny = $this->_smsDestiny;
		
		if(is_array($destiny))
		{
			foreach($destiny as $number)
			{
				$countryCode[$number] = $this->getCountryCode($number,0,$number);
			}
		}
		else
		{
			$countryCode = $this->getCountryCode($destiny,0,$destiny);
		}
		return ($countryCode);
	}
	/**
	 * Recursive search
	 * searches the country code in the 
	 * SMS's destiny number.
	 * @param string/int $number
	 * @param int $prefix_length
	 * @param string/int $destiny
	 */
	public function getCountryCode($number=0,$prefix_length=-1,$destiny=0)
	{
		if($prefix_length != -1 && strlen($number) <= 2) return false;
		
		
		// checks if this analysis was done before
		// and the country code was already found.
		if(is_array($this->_smsDestinyCode) && count($this->_smsDestinyCode) == count($this->_smsDestiny))
		{
			return $this->_smsDestinyCode; 
		}
		elseif($this->_smsDestinyCode != 0)
		{
			return $this->_smsDestinycode;	
		}
	    
		
		// getting the sms prices array
		$prices = $this->_smsPrices;
		
		// if there's only zeros on the prefix
		// then the prefix could not be found (00).
		if($prefix_length == 2)
		{
			return false;
		}
		if($number == $destiny)
		{
			foreach($prices as $code => $cost)
			{
				if($prefix_length=-1)
				{
					$prefix_length = strlen($code);
					$number = substr(str_replace('+','',$number),0,$prefix_length);	
					$prefix_length--;	
					$destiny = $number;
					
					break;
				}
				
			}
		}
		
	
		//print "$number - $destiny"; 
				// if prefix found
		if(array_key_exists($number,$prices))
		{ 
			//print $number;
			return $number;			
		}	
		
        $prefix_length--;
		
		// prefix not found - short the number and try again
		$number = substr($number,0,$prefix_length);
				
		return $this->getCountryCode($number,$prefix_length,$destiny);
		
	}
	
	/**
	 * Get details of the given numbers 
	 */
	public function getCountryDetails()
	{
		$countryCode = $this->getCountryCodes();
		
		if(is_array($countryCode))
		{
			foreach($countryCode as $num => $prefix)
			{
				$details[$num] = $this->_smsPrices[$prefix];
			}
		}
		else
		{
			$details = $this->_smsPrices[$countryCode];
		}
		return $details;
	}
	
	/**
	 * Send a request to the SMS server
	 * and get a XML response 
	 * @param String $destiny
	 */
	public function getResponse($destiny)
	{
		ob_start();
		//die(); exit;
		$DB = DBConnect();
		$details = $DB->Execute("SELECT * FROM `cc_sms_settings`");
		$data = $details->fetchNextObj();
		//$destiny = str_replace('+00','+',$destiny);
		//print $destiny; exit;
        $smsRequest = $data->base_link . '?username='.$data->username.'&password='.$data->password.'&from='.$this->_callerID.'&to='.$destiny.'&text='.urlencode(utf8_encode($this->_content));
		//$smsRequest = 'https://www.voicetrading.com/myaccount/sendsms.php?username=israelnumber&password=piterpen&from='.$this->_callerID.'&to='.$destiny.'&text='.urlencode(utf8_encode($this->_content));
		//print($smsRequest);
		$ch = curl_init($smsRequest);
			curl_setopt($ch, CURLOPT_URL, $smsRequest);
			//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			//curl_setopt($ch, CURLOPT_HEADER, false);
			//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$response = curl_exec($ch);
		curl_close($ch);
		
		//return $response;
		return(ob_get_clean() . $response);
	}
	
	public function logSms($destiny,$delayed=false)
	{	
		
		$QUERY = "SELECT  credit,useralias FROM cc_card WHERE username = '{$this->_a2billinguser}'";
		$DBHandle_max  = DbConnect();
		$resmax = $DBHandle_max -> Execute($QUERY);
		
		
		$prefix = $this->getCountryCode($destiny,-1,$destiny);
		
		if(!$prefix)
		{
			$sent = 0;
			$why = 4;
		}
		else
		{
			$prices = $this->getPrices();
			$cost = $prices[$prefix][0];
			//print $cost;
			
			$cust = $resmax->fetchRow();
			$user_credit = $cust[0];
			$alias = $cust[1];
		
			if($user_credit-$cost > 0)
			{
				$sent = 1;
				$why = 0;
				// sms could be sent
	
			
				$response = $this->getResponse($destiny);
				
				if(eregi("failure",$response))
				{
					$sent = 0;
					$why = 2;
					print $response;
				}
				elseif(eregi("Invalid Number",$response))
				{
					$sent = 0;
					$why = 3;
				}
	
				print $response;
			}
			else
			{
				$sent = 0;
				$why = 1; // no balance
			} 
		}
		
		//print $response; exit;
		$date = time();
		

		
		if($this->_update == false)
		{
			$QUERY = "INSERT INTO `cc_sms` (callerid,destiny,content,a2billinguser,sent,whynot,date_created,price) VALUES ('{$this->_callerID}','$destiny','{$this->_content}','{$this->_a2billinguser}','{$sent}','{$why}','{$date}','{$cost}')"; // username = '".$_SESSION["pr_login"]."' AND uipass = '".$_SESSION["pr_password"]."'";
			$DBHandle_max -> Execute($QUERY);
		}
		else
		{
			$resend = intval($_GET['resend']);
			$QUERY = "UPDATE `cc_sms` SET sent = '$sent',whynot = '$why' ,date_created = '$date' WHERE `smsID` = '$resend'";
			$DBHandle_max -> Execute($QUERY);
		}
		if($sent==1)
		{
			$credit = $user_credit - $cost;
			$cardid = $_SESSION['card_id'];
			$starttime = date("Y-m-d H:i:s"); 
			$DBHandle_max -> Execute("UPDATE cc_card SET credit = '$credit' WHERE username = '{$this->_a2billinguser}'");
			$DBHandle_max -> Execute("INSERT INTO `cc_call` (starttime,card_id,calledstation,sessionbill,terminatecauseid,src,destination,sipiax) VALUES ('{$starttime}','{$cardid}','{$destiny}','$cost','1','{$this->_a2billinguser}','$prefix','{$this->calltype}')");
		}
		if($why == 1)
		{
			print 'CREDIT IS TOO LOW';
		}


	}
	/**
	 * Sends the SMS Message to a certain
	 * destiny.
	 */
	public function sendMe()
	{
		
		/**
		* Needs to:	
		* First - check its cost
		* IF ok - send single sms
		* then check again for the next price
		* log each one with its result.
		*/

		
		if(is_array($this->_smsDestiny) && count($this->_smsDestiny) == 1)
		{
			$this->_smsDestiny = $this->_smsDestiny[0];
		}
		// if there is more than one destiny
		if(is_array($this->_smsDestiny))
		{
			foreach($this->_smsDestiny as $destiny)
			{
				if(strlen($destiny) > 2)
				{
					//print $destiny ."<br />"; 
					//print $destiny . "1<br />";
					// before sending the SMS we need to ensure
					// the prefix exists on our prices list
					//print $destiny;
					
					$log = $this->logSms(trim($destiny),false);
                    
					
				}
				
			}
			
		
		}
		else
		{	
			
			$log = $this->logSms(trim($this->_smsDestiny));

		}
		if($this->_rfh == false) { header("location: reports.php"); } 
	}
}
?>
