The script to terminate the calls if a total cost of the current calls exceed a credit's limit of an account
The script executed by "cron" service of Linux on recuring base and analyzing the channels and cut the calls when a credit on balance of the accounts goes out


<?php
/*
  $Id: billing_find_simult.php,v 5 2021/03/10 00:00:00 vlad-ga Exp $
   Author: vlad-ga

  Designed for Asterisk2Billing

  Copyright (c) 2020  free to use, package, distribute, alter.

*/

 
   //*******************************
   // V A R I A B L E S
   //*******************************


      /* Requirements: PHP , AsteriskBilling , Asterisk  */
      /* this program checks active outbound SIP channels in asterisk and      */
      /* terminates them if cost of calls exceeds credit or credit limit.      */   
      /* Console command line :  ~]# php billing_find_simult.php [ -v ]   */

   define('ASTERISK_BINARY', '/usr/sbin/asterisk');

   if ( isset($argc) && $argc > 1) {
      array_shift($argv);

      $allow = array ('-verbose','-v','verbose','v');

      if (!in_array($argv[0],$allow)) {
         print "\nCommand Format: php <path to executable> -v\n";
      } else {
         $option = $argv[0];
      }
   }

   // shell command to get string of active channels - Origination/Destination
   $str = shell_exec(ASTERISK_BINARY . ' -Rx "core show channels concise"');

   $strArray = explode("\n",$str);

   foreach ($strArray as $key => $value) {

      if ( (strpos($value,'!') !== false) && (strpos($value,'(Outgoing Line)') !== false) ) {

         // Active channels to array            
         $channel = explode('!',trim($value));
         if (strpos($channel[0], 'SIP/') !== false ) {
            $outGoingChannels[] = $channel;
         }
      }
   }

   // build array of accounts
   if (isset( $outGoingChannels ) ) {

      foreach ( $outGoingChannels as $key => $value ) {

         $bridgedTo   = trim($value[12]);   // Originating channel name bridged to destination

         if (!empty($bridgedTo) && $bridgedTo != '(None)') {

            $chandest   = trim($value[0]);   // Active destination channel name
   
            // shell command to get channel variables string of the Originating channel after bridged with Destination
            $str = shell_exec(ASTERISK_BINARY . ' -Rx "dialplan show chanvar ' . $bridgedTo . '"'  );

                if (!empty($str)) {

                    $strArray = explode("\n",$str);

                    foreach ($strArray as $k => $v ) {
                        $index = strpos($v,'=');
                        if ($index !== false) {
                            // channel variables to array
                            $data[substr($v,0,$index)] = trim(substr($v,($index + 1)));
                        }
                    }
                }

                if (isset($data['accountnumber'])
                        && is_numeric($data['accountnumber'])
                        && isset($data['credit'])
                        && isset($data['callrate'])
                        && is_numeric($data['callrate'])  ) {

               $account   = $data['accountnumber']; //accountcode

               // Initialize using account number as key
               if (!isset($current[$account]['highestbalance']))  {
                  if (is_numeric($data['credit'])) {
                     $current[$account]['highestbalance'] = $data['credit'];
                  } else {
                     $current[$account]['highestbalance'] = 0;
                  }
                  $current[$account]['totallengthofcalls'] = 0;
                  $current[$account]['totalperminuterate'] = 0;            
                  $current[$account]['channeldata'] = array();
               }

               if ($current[$account]['highestbalance'] == 0) {
                  $current[$account]['highestbalance'] = $data['credit'];
               } elseif ($data['credit'] > $current[$account]['highestbalance'] )  {
                  $current[$account]['highestbalance'] = $data['credit'];
               }

               //Asterisk CDR
               $ttime = billsec($chandest);

               // store remaining data
               $current[$account]['totalperminuterate'] = $current[$account]['totalperminuterate'] + $data['callrate'];

               $data['lengthofcall']    = $ttime;
               $data['channel']       = $chandest;
               $data['marktime']      = time();
               array_push( $current[$account]['channeldata'], $data); // Destination channel names et al

            
            }
         }
      }

      if (isset( $current) ) {

         $tick = 0;

         while ($tick <= 59) {   

            // loop each account
            foreach ($current as $key => $accountdata) {

               // calculate current total cost of calls for this account
               $cost = 0;
               $totallengthofcall = 0;
               foreach ($accountdata['channeldata'] as $ikey => $ival ) {
                  $tick = time() - $ival['marktime'];

                  $cost = $cost + ((($ival['lengthofcall'] + $tick)/60) * $ival['callrate']);
                  $totallengthofcall = $totallengthofcall + $ival['lengthofcall'] + $tick;
               }

               $channelcount    = count($accountdata['channeldata']);
               $averagelength    = ($totallengthofcall/60) / $channelcount;

               //one second's worth of call
               $onesecworth = $accountdata['totalperminuterate']/60;
      
               if ( $cost >= ( $accountdata['highestbalance'] - ($onesecworth*5) ) ) {

                  //terminate outbound channels for this account
                  dropChannel   ($accountdata['channeldata'] , $key);
                  unset($current[$key]);
                  if (count($current) == 0) exit;

               } elseif (isset($option)) {

                  // print to console
                  stats($key);

               }

            }

            sleep(1);

         }
      }
   }

   /****
      Hangup the channel(s)
   */
   function dropChannel ($channel = array(), $account = null) {
      if (!empty($channel) ) {

         foreach ($channel as $k => $v) {
            $str = shell_exec(ASTERISK_BINARY . ' -Rx "dialplan show chanvar ' . $v['channel'] . '"'  );
            $strArray = explode("\n",$str);
      
            foreach ($strArray as $kk => $vv ) {
               $index = strpos($vv,'=');
               if ($index !== false) {
                  // channel variables to array
                  $data[substr($vv,0,$index)] = trim(substr($vv,($index + 1)));
               }
            }

            if (isset($data['BRIDGEPEER']) && !empty($data['BRIDGEPEER']) ){
               stats($account);
               shell_exec(ASTERISK_BINARY . ' -Rx "channel request hangup ' . trim($v['channel']) . '"'  );
               print_r('Hung up channel "' . $v['channel'] . '" for account: ' . $account . ' [ Not enough Credit ]' . "\n");
            }
         }
      }
   }

   /****
      Get the current CDR billing for call in seconds
   */
   function billsec($channel) {
      if (!empty($channel)) {
         $reply = shell_exec(ASTERISK_BINARY . ' -Rx "core show channel ' . $channel . '"'  );
         $channeldata = explode("\n",$reply);
         if (!empty($channeldata)) {
            foreach($channeldata as $key => $value) {

               $index = strpos($value,'billsec=');
               if ( $index !== false) {
                  $seconds = explode('=',$value);
                  break;
               }
            }
            if (isset($seconds[1]) && is_numeric(trim($seconds[1]))) {            
               return trim($seconds[1]);
            } else {
               return 0;
            }
   
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }      

   /****
      Print some statistics
   */
   function stats($account) {

      global $accountdata,$channelcount,$averagelength,$cost;

      print_r("\n");
      print_r("           Account Code: " . $account ."\n");
      print_r("       Available Credit: " . $accountdata['highestbalance'] ."\n");
      print_r("           Active Calls: " . $channelcount . "\n" );
      print_r("Average Length of Calls: " . $averagelength * 60 . " Seconds\n");
      print_r("        Rate Per Minute: " . $accountdata['totalperminuterate'] . "\n");
      print_r("  Current Cost of Calls: " . $cost . "\n\n");

   }
?>
